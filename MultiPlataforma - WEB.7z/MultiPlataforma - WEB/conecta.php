<?php
    $conn = mysqli_connect("sql.freedb.tech","freedb_MucaLopes","kwsdhj5S?pnKb92","freedb_MucaFreeDB_TDS10");
    mysqli_set_charset($conn, "utf8");
    if (!$conn)
    {
        echo "Erro: ".mysqli_connect_error().PHP_EOL;
    }
?>