<?php
    include 'conecta.php';
    $Nome = $_POST['Nome'];
    $Idade = $_POST['Idade'];
    $Cidade = $_POST['Cidade'];

    $query = $conn->query("SELECT * FROM pessoa WHERE Nome='$Nome' AND Idade='$Idade' AND Cidade='$Cidade'");
    if (mysqli_num_rows($query) > 0) {
        echo "<script language='javascript' type='text/javascript'>
              alert('Pessoa já existe em nossa base de dados!');
              window.location.href='index.php';
              </script>";
        exit();
    }
    else
    {
        $sql = "INSERT INTO pessoa(Nome,Idade,Cidade) VALUES ('$Nome','$Idade','$Cidade')";
        if (mysqli_query($conn, $sql))
        {
            echo "<script language='javascript' type='text/javascript'>
              window.location.href='index.php';
              </script>"; 
        }
    }
    mysqli_close($conn);
?>